Plain text needs no cleaning.
